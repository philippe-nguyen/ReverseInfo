﻿namespace UtilitairesLibrary.Entities
{
    public class ExcelLocation
    {
        public string AdressLine1;
        public string AdressLine2;
        public string ApartmentNumber;
        public string City;
        public string PostalCode;
        public string Province;
        public string Country;
    }
}
