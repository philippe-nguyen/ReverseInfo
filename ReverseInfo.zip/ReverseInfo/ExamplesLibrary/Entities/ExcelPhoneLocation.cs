﻿using System.Collections.Generic;

namespace UtilitairesLibrary.Entities
{
    public class ExcelPhoneLocation
    {
        public List<PhoneName> PhoneNames = new List<PhoneName>();

        public ExcelLocation LocationDepth2;
        public ExcelLocation LocationDepth1;

        public bool IsValid = true;
    }

    public class PhoneName
    {
        public string Name;
        public string PhoneNumber;
    }
}
