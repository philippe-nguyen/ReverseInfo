﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using OfficeOpenXml;
using OfficeOpenXml.Style;
using ProApiLibrary.Data.Associations;
using ProApiLibrary.Data.Entities;
using UtilitairesLibrary.Entities;

namespace UtilitairesLibrary
{
    /// <summary>
    /// Copyright @2015 Whitepages, Inc.
    /// </summary>
    public class Utilitaires
    {
        private const int DefaultIndent = 4;

        public static string GetApiKey()
        {
            var apiKey = System.Configuration.ConfigurationManager.AppSettings["api_key"];
            if (!String.IsNullOrWhiteSpace(apiKey))
            {
                return apiKey;
            }

            throw new Exception("Please provide a valid API key.");
        }

        public static List<ExcelPhoneLocation> ReadExcelPhoneLocation(string filePath)
        {
            var lstPhoneLocation = new List<ExcelPhoneLocation>();

            var package = new ExcelPackage(new FileInfo(filePath));

            ExcelWorksheet workSheet = package.Workbook.Worksheets[1];

            for (int j = 2; j <= workSheet.Dimension.End.Row; j++)
            {
                var phoneLocation = new ExcelPhoneLocation();

                phoneLocation.LocationDepth1 = new ExcelLocation();

                //private const string StreetLine1 = "906 Dexter Ave N Apt 1328";

                var noCivique = ObtenirCellulle(workSheet, j, 1);
                var suffixe = ObtenirCellulle(workSheet, j, 5);
                var rue = ObtenirCellulle(workSheet, j, 6);
                var orientation = ObtenirCellulle(workSheet, j, 7).Trim().Replace("-", string.Empty);
                var apt = ObtenirCellulle(workSheet, j, 2).Trim().Replace("-", string.Empty);

                phoneLocation.LocationDepth1.AdressLine1 = (((noCivique + " " + rue).Trim() + " " + ObtenirSuffixe(suffixe)).Trim() + " " + orientation).Trim();

                if (!String.IsNullOrEmpty(apt))
                {
                    phoneLocation.LocationDepth1.AdressLine1 = apt + "-" + phoneLocation.LocationDepth1.AdressLine1;
                }

                phoneLocation.LocationDepth1.AdressLine2 = String.Empty;
                phoneLocation.LocationDepth1.City = ObtenirCellulle(workSheet, j, 10);
                phoneLocation.LocationDepth1.PostalCode = ObtenirCellulle(workSheet, j, 11).Replace(" ", String.Empty);
                phoneLocation.LocationDepth1.Province = ObtenirCellulle(workSheet, j, 12);

                lstPhoneLocation.Add(phoneLocation);
            }

            return lstPhoneLocation;
        }

        private static string ObtenirCellulle(ExcelWorksheet workSheet, int j, int k)
        {
            var cell = workSheet.Cells[j, k];
            string retValue = String.Empty;

            if (cell.Value != null)
            {
                retValue = cell.Value.ToString();
            }

            return retValue;
        }

        private static object ObtenirSuffixe(string suffixe)
        {
            if (suffixe.ToUpper() == "RU")
            {
                suffixe = String.Empty;
            }

            return suffixe;
        }

        public static string DumpExcelPhoneLocation(List<ExcelPhoneLocation> lstPhonesLocation, string outputDirectory)
        {
            var fileName = DateTime.Now.ToString("yyyyMMdd_HH_mm_ss_fff") + "_results.xlsx";
            var outputFilePath = System.IO.Path.Combine(outputDirectory, fileName);

            var file = new FileInfo(outputFilePath);

            // Create the package and make sure you wrap it in a using statement
            using (var package = new ExcelPackage(file))
            {
                // add a new worksheet to the empty workbook
                ExcelWorksheet worksheet = package.Workbook.Worksheets.Add("Whitepages results");

                // --------- Data and styling goes here -------------- //
                // Add some formatting to the worksheet
                worksheet.TabColor = Color.Blue;
                worksheet.DefaultRowHeight = 12;
                worksheet.Row(1).Height = 20;

                // Start adding the header
                // First of all the first row
                worksheet.Cells[1, 1].Value = "Name";
                worksheet.Cells[1, 2].Value = "Phone number";
                worksheet.Cells[1, 3].Value = "Address Line 1";
                worksheet.Cells[1, 4].Value = "Address Line 2";
                worksheet.Cells[1, 5].Value = "Apartment Number";
                worksheet.Cells[1, 6].Value = "City";
                worksheet.Cells[1, 7].Value = "Postal Code";
                worksheet.Cells[1, 8].Value = "Province";
                worksheet.Cells[1, 9].Value = "Country";

                //worksheet.Cells[1, 9].Value = "2_Address Line 1";
                //worksheet.Cells[1, 10].Value = "2_Address Line 2";
                //worksheet.Cells[1, 11].Value = "2_Apartment Number";
                //worksheet.Cells[1, 12].Value = "2_City";
                //worksheet.Cells[1, 13].Value = "2_Postal Code";
                //worksheet.Cells[1, 14].Value = "2_Province";
                //worksheet.Cells[1, 15].Value = "2_Country";

                using (var range = worksheet.Cells[1, 1, 1, 9])
                {
                    range.Style.Font.Bold = true;
                    range.Style.Fill.PatternType = ExcelFillStyle.Solid;
                    range.Style.Fill.BackgroundColor.SetColor(Color.Black);
                    range.Style.Font.Color.SetColor(Color.WhiteSmoke);
                    range.Style.ShrinkToFit = false;
                }

                int rowNumber = 2;
                foreach (var phoneLocation in lstPhonesLocation)
                {
                    if (phoneLocation.PhoneNames.Count == 0)
                    {
                        worksheet.Cells[rowNumber, 3].Value = phoneLocation.LocationDepth1.AdressLine1;
                        worksheet.Cells[rowNumber, 4].Value = phoneLocation.LocationDepth1.AdressLine2;
                        worksheet.Cells[rowNumber, 5].Value = phoneLocation.LocationDepth1.ApartmentNumber;
                        worksheet.Cells[rowNumber, 6].Value = phoneLocation.LocationDepth1.City;
                        worksheet.Cells[rowNumber, 7].Value = phoneLocation.LocationDepth1.PostalCode;
                        worksheet.Cells[rowNumber, 8].Value = phoneLocation.LocationDepth1.Province;
                        worksheet.Cells[rowNumber, 9].Value = phoneLocation.LocationDepth1.Country;

                        rowNumber++;
                    }
                    else
                    {
                        foreach (var phoneName in phoneLocation.PhoneNames)
                        {
                            worksheet.Cells[rowNumber, 1].Value = phoneName.Name;
                            worksheet.Cells[rowNumber, 2].Value = phoneName.PhoneNumber;
                            worksheet.Cells[rowNumber, 3].Value = phoneLocation.LocationDepth1.AdressLine1;
                            worksheet.Cells[rowNumber, 4].Value = phoneLocation.LocationDepth1.AdressLine2;
                            worksheet.Cells[rowNumber, 5].Value = phoneLocation.LocationDepth1.ApartmentNumber;
                            worksheet.Cells[rowNumber, 6].Value = phoneLocation.LocationDepth1.City;
                            worksheet.Cells[rowNumber, 7].Value = phoneLocation.LocationDepth1.PostalCode;
                            worksheet.Cells[rowNumber, 8].Value = phoneLocation.LocationDepth1.Province;
                            worksheet.Cells[rowNumber, 9].Value = phoneLocation.LocationDepth1.Country;

                            //worksheet.Cells[rowNumber, 9].Value = phoneLocation.LocationDepth2.AdressLine1;
                            //worksheet.Cells[rowNumber, 10].Value = phoneLocation.LocationDepth2.AdressLine2;
                            //worksheet.Cells[rowNumber, 11].Value = phoneLocation.LocationDepth2.ApartmentNumber;
                            //worksheet.Cells[rowNumber, 12].Value = phoneLocation.LocationDepth2.City;
                            //worksheet.Cells[rowNumber, 13].Value = phoneLocation.LocationDepth2.PostalCode;
                            //worksheet.Cells[rowNumber, 14].Value = phoneLocation.LocationDepth2.Province;
                            //worksheet.Cells[rowNumber, 15].Value = phoneLocation.LocationDepth2.Country;

                            rowNumber++;
                        }
                    }
                }

                // Fit the columns according to its content
                for (var i = 1; i <= 15; i++)
                {
                    worksheet.Column(i).AutoFit();
                }

                // Set some document properties
                package.Workbook.Properties.Title = "Whitepages extraction results";

                // save our new workbook and we are done!
                package.Save();
            }

            return fileName;
        }

        public static void DumpPerson(IPerson person, ExcelPhoneLocation phoneLocation, int depth, int indent = 0)
        {
            PrintName(person, indent);

            var phoneName = new PhoneName()
            {
                Name = person.Names == null ? String.Empty : String.Join(", ", person.Names)
            };
            phoneLocation.PhoneNames.Add(phoneName);

            WriteLine(indent, "Best Name:                   {0}", person.BestName);
            WriteLine(indent, "Names:                       {0}", person.Names == null ? "null" : String.Join(", ", person.Names));
            WriteLine(indent, "Age Range:                   {0}", person.AgeRange == null ? "null" : person.AgeRange.ToString());
            WriteLine(indent, "Gender:                      {0}", person.Gender);
            WriteLine(indent, "Type:                        {0}", person.Type);

            BestLocation(person.BestLocation, phoneLocation, depth, indent);

            DumpBaseEntity(person, phoneLocation, depth, indent);

            if (phoneLocation.PhoneNames.Last().PhoneNumber == null)
            {
                //Aucune association de téléphone trouvée, suppression de l'entité.
                phoneLocation.PhoneNames.Remove(phoneName);
            }
        }

        public static void DumpBusiness(IBusiness business, ExcelPhoneLocation phoneLocation, int depth, int indent = 0)
        {
            PrintName(business, indent);

            var phoneName = new PhoneName()
            {
                Name = business.Name
            };
            phoneLocation.PhoneNames.Add(phoneName);

            DumpBaseEntity(business, phoneLocation, depth, indent);

            if (phoneLocation.PhoneNames.Last().PhoneNumber == null)
            {
                //Aucune association de téléphone trouvée, suppression de l'entité.
                phoneLocation.PhoneNames.Remove(phoneName);
            }
        }

        public static void DumpLocation(ILocation location, ExcelPhoneLocation phoneLocation, int depth, int indent = 0)
        {
            PrintName(location, indent);

            //if (depth == 1)
            //{
            phoneLocation.LocationDepth1 = FillLocationObject(location);
            //}
            //else
            //{
            //    phoneLocation.LocationDepth2 = FillLocationObject(location);
            //}

            WriteLine(indent, "Address:                     {0}", location.Address);

            WriteLine(indent, "Address Type:                {0}", location.AddressType.HasValue ? location.AddressType.Value.ToString() : "null");
            WriteLine(indent, "Apartment Number:            {0}", String.IsNullOrWhiteSpace(location.AptNumber) ? "null" : location.AptNumber);
            WriteLine(indent, "Box Number:                  {0}", String.IsNullOrWhiteSpace(location.BoxNumber) ? "null" : location.BoxNumber);
            WriteLine(indent, "City:                        {0}", location.City);
            WriteLine(indent, "CountryCode:                 {0}", location.CountryCode);
            WriteLine(indent, "Deliverable:                 {0}", location.IsDeliverable.HasValue ? location.IsDeliverable.Value.ToString() : "null");
            WriteLine(indent, "Delivery Point:              {0}", location.DeliveryPoint.HasValue ? location.DeliveryPoint.Value.ToString() : "null");
            WriteLine(indent, "House:                       {0}", String.IsNullOrWhiteSpace(location.House) ? "null" : location.House);
            WriteLine(indent, "Latitude/Longitude:          {0}", location.LatLong);
            WriteLine(indent, "Not Receiving Mail Reason:   {0}", location.NotReceivingMailReason.HasValue ? location.NotReceivingMailReason.Value.ToString() : "null");
            WriteLine(indent, "Postal Code:                 {0}", location.PostalCode);
            WriteLine(indent, "Post Directional:            {0}", String.IsNullOrWhiteSpace(location.PostDir) ? "null" : location.PostDir);
            WriteLine(indent, "Pre Directional:             {0}", String.IsNullOrWhiteSpace(location.PreDir) ? "null" : location.PreDir);
            WriteLine(indent, "Receiving Mail:              {0}", location.IsReceivingMail.HasValue ? location.IsReceivingMail.Value.ToString() : "null");
            WriteLine(indent, "Standard Address Line1:      {0}", location.StandardAddressLine1);
            WriteLine(indent, "Standard Address Line2:      {0}", location.StandardAddressLine2);
            WriteLine(indent, "Standard Address Location:   {0}", location.StandardAddressLocation);
            WriteLine(indent, "State Code:                  {0}", location.StateCode);
            WriteLine(indent, "Street Name:                 {0}", String.IsNullOrWhiteSpace(location.StreetName) ? "null" : location.StreetName);
            WriteLine(indent, "Street Type:                 {0}", String.IsNullOrWhiteSpace(location.StreetType) ? "null" : location.StreetType);
            WriteLine(indent, "Usage:                       {0}", location.Usage.HasValue ? location.Usage.Value.ToString() : "null");
            WriteLine(indent, "ValidFor:                    {0}", location.ValidFor == null ? "null" : location.ValidFor.ToString());
            WriteLine(indent, "Zip4:                        {0}", String.IsNullOrWhiteSpace(location.Zip4) ? "null" : location.Zip4);

            DumpBaseEntity(location, phoneLocation, depth, indent);
        }

        private static ExcelLocation FillLocationObject(ILocation location)
        {
            var excelLocation = new ExcelLocation();
            excelLocation.AdressLine1 = location.StandardAddressLine1;
            excelLocation.AdressLine2 = location.StandardAddressLine2;
            excelLocation.ApartmentNumber = String.IsNullOrWhiteSpace(location.AptNumber) ? "null" : location.AptNumber;
            excelLocation.City = location.City;
            excelLocation.PostalCode = location.PostalCode;
            excelLocation.Province = location.StateCode;
            excelLocation.Country = location.CountryCode;

            return excelLocation;
        }

        public static void DumpPhone(IPhone phone, ExcelPhoneLocation phoneLocation, int depth, int indent = 0)
        {
            PrintName(phone, indent);

            if (depth == 1 && phoneLocation.PhoneNames.Count > 0 && phoneLocation.PhoneNames.Last().PhoneNumber == null)
            {
                //1er no de téléphone associé
                phoneLocation.PhoneNames.Last().PhoneNumber = phone.PhoneNumber;
            }
            else if (depth == 1 && phoneLocation.PhoneNames.Count > 0 && phoneLocation.PhoneNames.Last().PhoneNumber != null)
            {
                phoneLocation.PhoneNames.Add(new PhoneName()
                {
                    //La personne associée a plusieurs téléphones
                    Name = phoneLocation.PhoneNames.Last().Name,
                    PhoneNumber = phone.PhoneNumber
                });
            }
            else
            {
                phoneLocation.PhoneNames.Add(new PhoneName()
                {
                    PhoneNumber = phone.PhoneNumber
                });
            }

            WriteLine(indent, "Carrier:                     {0}", String.IsNullOrWhiteSpace(phone.Carrier) ? "null" : phone.Carrier);
            WriteLine(indent, "Country Calling Code:        {0}", phone.CountryCallingCode);
            WriteLine(indent, "Do Not Call:                 {0}", phone.DoNotCall.HasValue ? phone.DoNotCall.Value.ToString() : "null");
            WriteLine(indent, "Extension:                   {0}", phone.Extension ?? "null");
            WriteLine(indent, "LineType:                    {0}", phone.LineType);
            WriteLine(indent, "PhoneNumber:                 {0}", phone.PhoneNumber);
            WriteLine(indent, "Is Prepaid:                  {0}", phone.IsPrepaid.HasValue ? phone.IsPrepaid.Value.ToString() : "null");
            WriteLine(indent, "Reputation:                  {0}", GetSpamScore(phone));
            WriteLine(indent, "Is Valid:                    {0}", phone.IsValid);
            WriteLine(indent, "Is Connected:				{0}", phone.IsConnected);
            BestLocation(phone.BestLocation, phoneLocation, depth, indent);

            DumpBaseEntity(phone, phoneLocation, depth, indent);

        }

        #region Helper Methods

        private static int? GetSpamScore(IPhone phone)
        {
            return Phone.GetSpamScore(phone.Reputation);
        }

        private static void BestLocation(ILocation location, ExcelPhoneLocation phoneLocation, int depth, int indent)
        {
            if (depth > 1 && location != null)
            {
                WriteLine(indent, "Best Location:               {0}", location.Name);
            }
        }

        #endregion

        #region Formatting / Printing Methods

        private static void DumpBaseEntity(IEntity entity, ExcelPhoneLocation phoneLocation, int depth, int indent)
        {
            if (depth > 1)
            {
                var businesses = entity.BusinessAssociations;
                if (businesses != null)
                {
                    var list = businesses.ToList();
                    if (list.Any())
                    {
                        foreach (var business in list)
                        {
                            DumpBusinessAssociation(business, phoneLocation, depth - 1, indent + DefaultIndent);
                        }
                    }
                }

                var locations = entity.LocationAssociations;
                if (locations != null)
                {
                    var list = locations.ToList();
                    if (list.Any())
                    {
                        foreach (var location in list)
                        {
                            DumpLocationAssociation(location, phoneLocation, depth - 1, indent + DefaultIndent);
                        }
                    }
                }

                var people = entity.PersonAssociations;
                if (people != null)
                {
                    var list = people.ToList();
                    if (list.Any())
                    {
                        foreach (var person in list)
                        {
                            DumpPersonAssociation(person, phoneLocation, depth - 1, indent + DefaultIndent);
                        }
                    }
                }

                var phones = entity.PhoneAssociations;
                if ((phones != null))
                {
                    var list = phones.ToList();
                    if (list.Any())
                    {
                        foreach (var phone in list)
                        {
                            DumpPhoneAssociation(phone, phoneLocation, depth - 1, indent + DefaultIndent);
                        }
                    }
                }
            }
        }

        private static void DumpPersonAssociation(PersonAssociation association, ExcelPhoneLocation phoneLocation, int depth, int indent)
        {
            DumpPerson(association.Person, phoneLocation, depth, indent);
        }

        private static void DumpBusinessAssociation(BusinessAssociation association, ExcelPhoneLocation phoneLocation, int depth, int indent)
        {
            DumpBusiness(association.Business, phoneLocation, depth, indent);
        }

        private static void DumpLocationAssociation(LocationAssociation association, ExcelPhoneLocation phoneLocation, int depth, int indent)
        {
            WriteLine(indent, "Contact Type:                {0}", association.ContactType.HasValue ? association.ContactType.Value.ToString() : "null");
            WriteLine(indent, "Location:");
            DumpLocation(association.Location, phoneLocation, depth, indent + DefaultIndent);
        }

        private static void DumpPhoneAssociation(PhoneAssociation association, ExcelPhoneLocation phoneLocation, int depth, int indent)
        {
            WriteLine(indent, "Contact Type:                {0}", association.ContactType.HasValue ? association.ContactType.Value.ToString() : "null");
            WriteLine(indent, "Phone:");
            DumpPhone(association.Phone, phoneLocation, depth, indent + DefaultIndent);
        }


        private static void PrintName(IEntity entity, int indent)
        {
            WriteLine(indent, "Name:                        {0}", entity.Name);
        }

        private static void WriteLine(int indent, string format, Object value = null)
        {
            //Indent(indent);
            //Console.WriteLine(format, value);
        }

        private static void Indent(int howMany)
        {
            for (var i = 0; i < howMany; i++)
            {
                Console.Out.Write(" ");
            }
        }

        #endregion

    }

}
