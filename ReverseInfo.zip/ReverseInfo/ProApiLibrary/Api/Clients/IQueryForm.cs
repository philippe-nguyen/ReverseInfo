﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using ProApiLibrary.Api.Queries;

namespace ProApiLibrary.Api.Clients
{
	public interface IQueryForm
	{

	}
}
