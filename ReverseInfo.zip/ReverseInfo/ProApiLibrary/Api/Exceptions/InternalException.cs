﻿namespace ProApiLibrary.Api.Exceptions
{
	/// <summary>
	/// Copyright 2015 Whitepages, Inc.
	/// </summary>
	public class InternalException : ResponseException
	{
		public InternalException(string message) : base(message)
		{
			
		}
	}
}
