﻿namespace ProApiLibrary.Data.Entities
{
	public enum Durability
	{
		Durable,
		Ephemeral,
		Temporary
	}

}
