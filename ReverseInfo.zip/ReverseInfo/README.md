# Whitepages PROAPI CLient Library

©2015, Whitepages Inc.

## Description

The native C# client library to Whitepages PROAPI.

## Dependencies

This library depends on the following resources:

* [Newsoft Json.NET](https://www.nuget.org/packages/newtonsoft.json/)

This library has been tested against Json.NET 6.0.8.

## License

See [LICENSE.txt](LICENSE.txt)
