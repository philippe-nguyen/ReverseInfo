﻿using System;
using System.Collections.Generic;
using ProApiLibrary.Api.Clients;
using ProApiLibrary.Api.Queries;
using UtilitairesLibrary;
using UtilitairesLibrary.Entities;

namespace ReverseAddress
{
    /// <summary>
    /// Copyright @2015 Whitepages, Inc.
    /// </summary>
    public class ReverseAddress
    {
        public List<ExcelPhoneLocation> FetchPhoneFromLocation(List<ExcelPhoneLocation> lstPhoneLocation, string apiKey)
        {
            var lstRetourPhoneLocation = new List<ExcelPhoneLocation>();

            var client = new Client(apiKey);

            foreach (var phoneLocation in lstPhoneLocation)
            {
                try
                {
                    var query = new LocationQuery(phoneLocation.LocationDepth1.AdressLine1, 
                        phoneLocation.LocationDepth1.AdressLine2, 
                        phoneLocation.LocationDepth1.City, 
                        phoneLocation.LocationDepth1.Province, 
                        phoneLocation.LocationDepth1.PostalCode);

                    var response = client.FindLocations(query);

                    if (response != null && response.IsSuccess)
                    {
                        foreach (var location in response.Results)
                        {
                            var phoneLocationRetour = new ExcelPhoneLocation();

                            Utilitaires.DumpLocation(location, phoneLocationRetour, 3);

                            lstRetourPhoneLocation.Add(phoneLocationRetour);
                        }
                    }
                    else
                    {
                        phoneLocation.IsValid = false;
                    }
                }
                catch (Exception)
                {
                    phoneLocation.IsValid = false;
                }
            }

            return lstRetourPhoneLocation;
        }
    }
}
