﻿using System.Collections.Generic;
using System.Xml.Serialization;
using ProApiLibrary.Api.Clients;
using ProApiLibrary.Api.Exceptions;
using ProApiLibrary.Api.Queries;
using UtilitairesLibrary;
using UtilitairesLibrary.Entities;

namespace ReversePhone
{
    /// <summary>
    /// Copyright @2015 Whitepages, Inc.
    /// </summary>
    public class ReversePhone
    {
        public List<ExcelPhoneLocation> FetchLocationFromPhone(List<string> lstPhoneNumbers, string apiKey)
        {
            var client = new Client(apiKey);

            var lstPhoneLocation = new List<ExcelPhoneLocation>();
            foreach (var phoneNumber in lstPhoneNumbers)
            {
                var phoneLocation = new ExcelPhoneLocation();
                phoneLocation.PhoneNames.Add(new PhoneName(){PhoneNumber = phoneNumber}); 

                try
                {
                    var query = new PhoneQuery(phoneNumber);
                    var response = client.FindPhones(query);

                    if ((response != null) && (response.IsSuccess))
                    {
                        foreach (var phone in response.Results)
                        {
                            Utilitaires.DumpPhone(phone, phoneLocation, 3);
                        }
                    }
                }
                catch (FindException)
                {
                    phoneLocation.IsValid = false;
                }

//                var xml = @"<?xml version=""1.0"" encoding=""utf-16""?>
//                            <ExcelPhoneLocation xmlns:xsi=""http://www.w3.org/2001/XMLSchema-instance"" xmlns:xsd=""http://www.w3.org/2001/XMLSchema"">
//                              <PhoneNumber>4182046251</PhoneNumber>
//                              <LocationDepth2>
//                                <AdressLine1 />
//                                <AdressLine2 />
//                                <ApartmentNumber>null</ApartmentNumber>
//                                <Province>QC</Province>
//                                <Country>CA</Country>
//                              </LocationDepth2>
//                              <LocationDepth1>
//                                <AdressLine1>310 Saint-Mathias Rue</AdressLine1>
//                                <AdressLine2 />
//                                <ApartmentNumber>null</ApartmentNumber>
//                                <City>Quebec</City>
//                                <PostalCode>G1K 1B2</PostalCode>
//                                <Province>QC</Province>
//                                <Country>CA</Country>
//                              </LocationDepth1>
//                              <IsValid>true</IsValid>
//                            </ExcelPhoneLocation>";
//                phoneLocation = ConvertToObject<ExcelPhoneLocation>(xml);

                lstPhoneLocation.Add(phoneLocation);
            }

            return lstPhoneLocation;
        }

        public string ConvertToXml<T>(T obj)
        {
            var stringwriter = new System.IO.StringWriter();
            var serializer = new XmlSerializer(typeof(T));

            serializer.Serialize(stringwriter, obj);

            return stringwriter.ToString();
        }

        public T ConvertToObject<T>(string xml)
        {
            var stringReader = new System.IO.StringReader(xml);
            var serializer = new XmlSerializer(typeof(T));

            var obj = serializer.Deserialize(stringReader);

            return (T)obj;
        }
    }
}
