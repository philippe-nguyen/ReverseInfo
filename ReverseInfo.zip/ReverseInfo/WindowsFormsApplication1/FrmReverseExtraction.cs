﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Windows.Forms;
using UtilitairesLibrary;
using UtilitairesLibrary.Entities;

namespace WhitepagesReversePhone
{
    public partial class FrmReverseExtraction : Form
    {
        public FrmReverseExtraction()
        {
            InitializeComponent();
        }

        private void btnChoisirDossier_Click(object sender, EventArgs e)
        {
            DialogResult result = folderBrowserDialog1.ShowDialog();
            if (result == DialogResult.OK)
            {
                txtOutputDirectory.Text = folderBrowserDialog1.SelectedPath;
            }
        }

        private void btnChoisirFichier_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                txtInputFile.Text = openFileDialog1.FileName;
            }
        }

        private void btnExtract_Click(object sender, EventArgs e)
        {
            try
            {
                if (String.IsNullOrEmpty(txtInputFile.Text) ||
                    String.IsNullOrEmpty(txtOutputDirectory.Text) || String.IsNullOrEmpty(txtApiKey.Text))
                {
                    MessageBox.Show("Please fill all fields from the form.", String.Empty, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }

                List<ExcelPhoneLocation> lstAddresses = null;
                List<ExcelPhoneLocation> phoneLocations = null;

                var reverseAddress = true;

                if (reverseAddress)
                {
                    lstAddresses = FetchAddresses(txtInputFile.Text);
                    var reverseAddressService = new ReverseAddress.ReverseAddress();

                    phoneLocations = reverseAddressService.FetchPhoneFromLocation(lstAddresses, txtApiKey.Text);
                }
                else
                {
                    var lstPhoneNumbers = FetchPhoneNumbers();
                    var reversePhoneService = new ReversePhone.ReversePhone();

                    phoneLocations = reversePhoneService.FetchLocationFromPhone(lstPhoneNumbers, txtApiKey.Text);
                }

                string outputFilePath = Utilitaires.DumpExcelPhoneLocation(phoneLocations, txtOutputDirectory.Text);

                MessageBox.Show(String.Format("Data extraction completed. File name : {0}.", outputFilePath));
            }
            catch (Exception ex)
            {
                MessageBox.Show(String.Format("An error occured : {0}.", ex.Message + "\r\n" + ex.StackTrace));
            }
        }

        private List<ExcelPhoneLocation> FetchAddresses(string filePath)
        {
            return Utilitaires.ReadExcelPhoneLocation(filePath);
        }

        private List<string> FetchPhoneNumbers()
        {
            var lstPhonesInput = new List<string>();

            using (var sr = new StreamReader(txtInputFile.Text))
            {
                var line = sr.ReadLine();
                while (!String.IsNullOrEmpty(line))
                {
                    var phoneNumber = CleanPhoneNumber(line);

                    lstPhonesInput.Add(phoneNumber);

                    line = sr.ReadLine();
                }
            }

            return lstPhonesInput;
        }

        private string CleanPhoneNumber(string line)
        {
            return line.Replace("(", string.Empty).Replace(")", string.Empty).Replace("-", string.Empty).Replace(" ", string.Empty);
        }
    }
}
