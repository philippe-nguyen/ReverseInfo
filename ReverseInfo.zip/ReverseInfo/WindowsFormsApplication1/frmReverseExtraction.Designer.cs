﻿namespace WhitepagesReversePhone
{
    partial class FrmReverseExtraction
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.P = new System.Windows.Forms.Label();
            this.txtInputFile = new System.Windows.Forms.TextBox();
            this.btnChoisirFichier = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txtOutputDirectory = new System.Windows.Forms.TextBox();
            this.btnChoisirDossier = new System.Windows.Forms.Button();
            this.btnExtract = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.label2 = new System.Windows.Forms.Label();
            this.txtApiKey = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // P
            // 
            this.P.AutoSize = true;
            this.P.Location = new System.Drawing.Point(12, 33);
            this.P.Name = "P";
            this.P.Size = new System.Drawing.Size(53, 13);
            this.P.TabIndex = 4;
            this.P.Text = "Input file :";
            // 
            // txtInputFile
            // 
            this.txtInputFile.Location = new System.Drawing.Point(123, 26);
            this.txtInputFile.Name = "txtInputFile";
            this.txtInputFile.Size = new System.Drawing.Size(530, 20);
            this.txtInputFile.TabIndex = 5;
            // 
            // btnChoisirFichier
            // 
            this.btnChoisirFichier.Location = new System.Drawing.Point(659, 23);
            this.btnChoisirFichier.Name = "btnChoisirFichier";
            this.btnChoisirFichier.Size = new System.Drawing.Size(75, 23);
            this.btnChoisirFichier.TabIndex = 6;
            this.btnChoisirFichier.Text = "...";
            this.btnChoisirFichier.UseVisualStyleBackColor = true;
            this.btnChoisirFichier.Click += new System.EventHandler(this.btnChoisirFichier_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 72);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(88, 13);
            this.label1.TabIndex = 9;
            this.label1.Text = "Output directory :";
            // 
            // txtOutputDirectory
            // 
            this.txtOutputDirectory.Location = new System.Drawing.Point(123, 69);
            this.txtOutputDirectory.Name = "txtOutputDirectory";
            this.txtOutputDirectory.Size = new System.Drawing.Size(530, 20);
            this.txtOutputDirectory.TabIndex = 8;
            // 
            // btnChoisirDossier
            // 
            this.btnChoisirDossier.Location = new System.Drawing.Point(659, 67);
            this.btnChoisirDossier.Name = "btnChoisirDossier";
            this.btnChoisirDossier.Size = new System.Drawing.Size(75, 23);
            this.btnChoisirDossier.TabIndex = 7;
            this.btnChoisirDossier.Text = "...";
            this.btnChoisirDossier.UseVisualStyleBackColor = true;
            this.btnChoisirDossier.Click += new System.EventHandler(this.btnChoisirDossier_Click);
            // 
            // btnExtract
            // 
            this.btnExtract.Location = new System.Drawing.Point(659, 155);
            this.btnExtract.Name = "btnExtract";
            this.btnExtract.Size = new System.Drawing.Size(75, 23);
            this.btnExtract.TabIndex = 10;
            this.btnExtract.Text = "Extract";
            this.btnExtract.UseVisualStyleBackColor = true;
            this.btnExtract.Click += new System.EventHandler(this.btnExtract_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 111);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(48, 13);
            this.label2.TabIndex = 11;
            this.label2.Text = "Api key :";
            // 
            // txtApiKey
            // 
            this.txtApiKey.Location = new System.Drawing.Point(123, 111);
            this.txtApiKey.Name = "txtApiKey";
            this.txtApiKey.Size = new System.Drawing.Size(240, 20);
            this.txtApiKey.TabIndex = 12;
            // 
            // FrmReverseExtraction
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(745, 190);
            this.Controls.Add(this.txtApiKey);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnExtract);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtOutputDirectory);
            this.Controls.Add(this.btnChoisirDossier);
            this.Controls.Add(this.btnChoisirFichier);
            this.Controls.Add(this.txtInputFile);
            this.Controls.Add(this.P);
            this.Name = "FrmReverseExtraction";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Whitepages";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
        private System.Windows.Forms.Label P;
        private System.Windows.Forms.TextBox txtInputFile;
        private System.Windows.Forms.Button btnChoisirFichier;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtOutputDirectory;
        private System.Windows.Forms.Button btnChoisirDossier;
        private System.Windows.Forms.Button btnExtract;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtApiKey;
    }
}

